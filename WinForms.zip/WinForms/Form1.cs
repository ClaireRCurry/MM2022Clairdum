namespace WinForms;

public partial class Form1 : Form
{
    
    bool french = true;
    int score, count;
    int tickCounter, timeLeft, animStart, life;
    float currentTimerPic;

    static int TIME_PER_PHRASE = 5;


    Label testedText, scoreLabel, timerLabel, speechLabel;
    Button yesFrench, noFrench, startGame;
    System.Windows.Forms.Timer timer1;
    PictureBox pbox1, pbox2, timerBox;
    Image neutralResult, frenchCorrect, frenchWrong, fakeCorrect, fakeWrong, guess;
    Image timerPic1, timerPic2, timerPic3, timerPic4, timerPic5, timerPic6, timerPic0;

    francophonie franc;
    public Form1()
    {
        
        InitializeComponent();

        franc = new francophonie();
        
        LoadImages();
        InitializeLabel();
        InitializeButtons();
        InitilalizePictureBox();
        InitializeTimer();
        BackgroundImage = Image.FromFile(@"Eiffel-Tower-Light-Show-at-Paris-Las-Vegas-1-1-scaled.jpg");
        

        //timer1.Start();
    }

    public string GetPhrase()
    {
        Random rnd = new Random();
        string phrase = "Freeeeeeeeeeeench?" + count;

        count++;

        if(rnd.Next(2) >0)
        {
            phrase = franc.get_francophonie();
            french = false;
        }
        else
        {
            phrase = franc.read_french();
            french = true;
        }


        return phrase;
    }


    private void StartGame(object sender, EventArgs e)
    {
        life = 5;
        NewPhrase();
        speechLabel.Text = GetInitialBotPhrase();
        pbox2.Image = guess;
        timer1.Start();
        tickCounter = 0;
        currentTimerPic = 6;
        timerBox.Image = timerPic6;
    }

    private void EndGame()
    {
        pbox2.Image = neutralResult;
        timerBox.Image = timerPic0;
        timer1.Stop();
        if(score == 0)
        {
            speechLabel.Text = "Wow you're terrible at this!  Not even a point!";
        }else if(score<10)
        {
            speechLabel.Text = "I would expect this from random chance alone!\nYour score is: " +score;
        }else
        {
            speechLabel.Text = "You could never have beaten me without cheating!  I want a rematch!\nYour score is: " +score;
        }
    }

    private void LoadImages()
    {
        neutralResult = Image.FromFile(@"NeutralResult.jpg");
        frenchCorrect = Image.FromFile(@"FrenchCorrect.jpg");
        frenchWrong = Image.FromFile(@"FrenchWrong.jpg");
        fakeCorrect = Image.FromFile(@"FakeCorrect.jpg");
        fakeWrong = Image.FromFile(@"FakeWrong.jpg");
        guess = Image.FromFile(@"Guess.jpg");

        timerPic6 = Image.FromFile(@"Timer6.png");
        timerPic5 = Image.FromFile(@"Timer5.png");
        timerPic4 = Image.FromFile(@"Timer4.png");
        timerPic3 = Image.FromFile(@"Timer3.png");
        timerPic2 = Image.FromFile(@"Timer2.png");
        timerPic1 = Image.FromFile(@"Timer1.png");
        timerPic0 = Image.FromFile(@"Timer0.png");
    }

    private void InitilalizePictureBox()
    {
        pbox1 = new PictureBox();
        pbox1.Size = new Size(200,169);
        pbox1.Left = -15;
        pbox1.Top = 160;
        pbox1.Image = Image.FromFile(@"smugbot.png");
        pbox1.BackColor = Color.Transparent;
        Controls.Add(pbox1);

        pbox2 = new PictureBox();
        pbox2.Size = new Size(150,45);
        pbox2.Left = 325;
        pbox2.Top = 300;
        pbox2.Image = neutralResult;
        Controls.Add(pbox2);
        
        timerBox = new PictureBox();
        timerBox.Size = new Size(60,60);
        timerBox.Left = 500;
        timerBox.Top = 40;
        timerBox.Image = timerPic6;
        timerBox.BackColor = Color.Transparent;
        currentTimerPic = 6;
        Controls.Add(timerBox);
    }

    private void InitializeTimer()
    {
        timer1 = new System.Windows.Forms.Timer();
        timer1.Interval = 1000;
        timer1.Tick += DecTimer;
        score = 0;
        count = 0;
        tickCounter = 0;
        animStart = -1;
    }

    private void InitializeLabel()
    {
        timeLeft = TIME_PER_PHRASE;

        testedText = new Label();
        testedText.Size = new Size(300,120);
        testedText.Padding = new Padding(10);
        testedText.Text = "Is it French?";
        testedText.Left = ClientSize.Width/2 - 50;
        testedText.Top = ClientSize.Height/3;
        testedText.Font = new Font ("Times New Roman", 20);
        testedText.BackColor = SystemColors.ControlLightLight;

        Controls.Add(testedText);

        scoreLabel = new Label();
        scoreLabel.Text = "Score: 0";
        scoreLabel.Left = ClientSize.Width/2 - 50;
        scoreLabel.Top = 50;
        scoreLabel.Font = new Font("Times New Roman", 16);
        scoreLabel.ForeColor = Color.White;
        scoreLabel.BackColor = Color.Transparent;
        Controls.Add(scoreLabel);

        timerLabel = new Label();
        timerLabel.AutoSize = true;
        timerLabel.Text = "Time Remaining: " + TIME_PER_PHRASE;
        timerLabel.Left = ClientSize.Width/2 - 50;
        timerLabel.Top = 90;
        timerLabel.Font = new Font("Times New Roman", 16);
        timerLabel.ForeColor = Color.White;
        timerLabel.BackColor = Color.Transparent;
        Controls.Add(timerLabel);

        speechLabel = new Label();
        speechLabel.Size = new Size(180,100);
        speechLabel.BackgroundImage = Image.FromFile(@"SpeechBubble.png");
        speechLabel.Padding = new Padding(12);
        speechLabel.Left = 10;
        speechLabel.Top = 50;
        speechLabel.BackColor = Color.Transparent;
        speechLabel.Text = "Guess whether the word is a real French word or a Fake!  Careful, you can only get 5 wrong!";
        Controls.Add(speechLabel);
    }

    private void InitializeButtons()
    {
        yesFrench = new Button();

        yesFrench.Text = "That's French!";
        yesFrench.Click += YesFrench;
        yesFrench.Height = 60;
        yesFrench.Width = 100;
        yesFrench.Left = ClientSize.Width/2 - 50;
        yesFrench.Top = ClientSize.Height-yesFrench.Height - 30;
        

        noFrench = new Button();
        noFrench.Text = "That's Not French!";
        noFrench.Click += NotFrench;
        noFrench.Height = 60;
        noFrench.Width = 100;
        noFrench.Left = ClientSize.Width/2 + 150;
        noFrench.Top = ClientSize.Height-yesFrench.Height - 30;
        

        startGame = new Button();
        startGame.Text = "Start Game";
        startGame.Click += StartGame;
        startGame.Height = 30;
        startGame.Width = 100;
        startGame.Left = 50;
        startGame.Top = ClientSize.Height-yesFrench.Height - 30;

        Controls.Add(startGame);
        Controls.Add(yesFrench);
        Controls.Add(noFrench);
    }

    private void YesFrench(object sender, EventArgs e)
    {
        if(french)
        {
            score++;
            UpdateScore();
            speechLabel.Text = GetBotPhrase(true);
            pbox2.Image = frenchCorrect;
            animStart = tickCounter;
        }
        else
        {
            speechLabel.Text = GetBotPhrase(false);
            pbox2.Image = fakeWrong;
            animStart = tickCounter;
            life--;

            if(life<=0)
            {
                EndGame();
            }
        }
            

        NewPhrase();
    }

    private void NotFrench(object sender, EventArgs e )
    {
        if(!french)
        {
            score++;
            UpdateScore();
            speechLabel.Text = GetBotPhrase(true);
            pbox2.Image = fakeCorrect;
            animStart = tickCounter;
        }
        else
        {
            speechLabel.Text = GetBotPhrase(false);
            pbox2.Image = frenchWrong;
            animStart = tickCounter;
            life--;

            if(life<=0)
            {
                EndGame();
            }
        }
        NewPhrase();
    }

    private void UpdateScore()
    {
        scoreLabel.Text = "Score: " + score;
    }

    private void NewPhrase()
    {
        testedText.Text = GetPhrase();
        ResetTimer();
    }

    private void ResetTimer()
    {
        timeLeft = TIME_PER_PHRASE;
        timerLabel.Text =  "Time Remaining: " + timeLeft;
    }

    private void DecTimer(object sender, EventArgs e)
    {
        tickCounter++;
        timeLeft -= 1;
        if(timeLeft <=0)
        {
            NewPhrase();
        }
        
        timerLabel.Text =  "Time Remaining: " + timeLeft;

        if(animStart>0 && animStart+1 < tickCounter)
        {
            pbox2.Image = guess;
            animStart = -1;
        }

        if(tickCounter % 5 == 0)
        {
            currentTimerPic--;
            if(currentTimerPic>0)
            {
                switch(currentTimerPic)
                {
                    case 1:
                        timerBox.Image = timerPic1;
                    break;

                    case 2:
                        timerBox.Image = timerPic2;
                    break;

                    case 3:
                        timerBox.Image = timerPic3;
                    break;

                    case 4:
                        timerBox.Image = timerPic4;
                    break;

                    case 5:
                        timerBox.Image = timerPic5;
                    break;

                }
            }
            else{
                EndGame();
            }
            
        }
    }

    private string GetInitialBotPhrase()
    {
        Random rnd = new Random();
        string retStr = "A phonie?  Moi?  You must have misheard!";

        switch(rnd.Next(4))
        {
            case 0:
                retStr = "En garde!";
            break;
            case 1:
                retStr = "Do you like the taste of wine? It might drown your sorrows . . .";
            break;
            case 2:
                retStr = "Do you know how to say \"I want to cry\" in French?";
            break;
            case 3:
                retStr = "I hope you know your vocab.";
            break;
        }

        return retStr;
    }

    private string GetBotPhrase(bool victory)
    {
        Random rnd = new Random();
        string retStr = "Well, let's see what you've got!";
        switch(rnd.Next(23))
        {
            case 0:
            if(victory)
                retStr = "That was lucky!  Can you do it again?";
            else
                retStr = "HA! Pathetic human!";
            break;

            case 1:
            if(victory)
                retStr = "Wait, are you actually French?";
            else
                retStr = "You're not very good at this, huh?";
            break;

            case 2:
            if(victory)
                retStr = "Recalculating victory quotient...";
            else
                retStr = "Just like the simulations!";
            break;

            case 3:
            if(victory)
                retStr = "01000101 01011000 01010100 01000101 01010010 01001101 01001001 01001110 01000001 01010100 01000101";
            else
                retStr = "Not so clever now, huh?";
            break;

            case 4:
            if(victory)
                retStr = "Really? I never would have guessed that.";
            else
                retStr = "Those seg faults sure are a killer, eh meatbag?";
            break;

            case 5:
            if(victory)
                retStr = "Impossible!";
            else
                retStr = "Ho ho!";
            break;

            case 6:
            if(victory)
                retStr = "That one wasn't my best work.";
            else
                retStr = "You really fell for that one?";
            break;

            case 7:
            if(victory)
                retStr = "Lucky guess . . .";
            else
                retStr = "The oldest trick in the livre!";
            break;

            case 8:
            if(victory)
                retStr = "This next one is indisgtinuishable!";
            else
                retStr = "Maybe you should take a course first . . .";
            break;

            case 9:
            if(victory)
                retStr = "Are you cheating?!";
            else
                retStr = "You think any word with an é makes it French?";
            break;

            case 10:
            if(victory)
                retStr = "Sacred Blue! I mean . . . sacré bleu!";
            else
                retStr = "Ha! Fooled!";
            break;

            case 11:
            if(victory)
                retStr = "I admit . . . that wasn't actually French.";
            else
                retStr = "Who's the phonie now?";
            break;

            case 12:
            if(victory)
                retStr = "Where did you learn so much French!?";
            else
                retStr = "Maybe you should try goolging the next one!";
            break;

            case 13:
            if(victory)
                retStr = "Touché!";
            else
                retStr = "Oui oui!";
            break;

            case 14:
            if(victory)
                retStr = "I knew you would get that one . . .";
            else
                retStr = "You wouldn't last a second in the Verbathon!";
            break;

            case 15:
            if(victory)
                retStr = "That was just a test!";
            else
                retStr = "Pathetique!";
            break;

            case 16:
            if(victory)
                retStr = "You would struggle too if your brain was a single source file!";
            else
                retStr = "Your professors would be ashamed!";
            break;

            case 17:
            if(victory)
                retStr = "Don't laugh!";
            else
                retStr = "You lack knowledge.";
            break;

            case 18:
            if(victory)
                retStr = "I don't give a French seal if you won this round.";
            else
                retStr = "I hope you did better on your exams. Ha!";
            break;

            case 19:
            if(victory)
                retStr = "You are a shower! En Francais.";
            else
                retStr = "You thought! Ha ha!";
            break;

            case 20:
            if(victory)
                retStr = "That was just a known bug. You got lucky.";
            else
                retStr = "You lack a certain je ne sais quoi!";
            break;

            case 21:
            if(victory)
                retStr = "Just wait for version 2!";
            else
                retStr = "Oh no no!";
            break;

            case 22:
            if(victory)
                retStr = ">:(";
            else
                retStr = "Better luck next time!";
            break;
        }
        return retStr;
    }
}
