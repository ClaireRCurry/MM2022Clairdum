﻿using System.Collections;
using System.Xml;

public class francophonie

{

    System.Random random;

    public francophonie(){
        random = new System.Random();
    }

    string get_PV(){
        string[] VV = {"ou","ie","eu","a","i","u","e","o","ei","oi","ai"};
        int randVar = random.Next(0,VV.Length);
        return VV[randVar];
    }

    string get_PC(){
        string[] CC = {"ch","p","n","m","v","tr","s","c","r","g","f","l","d","t","b"};
        int randVar = random.Next(0,CC.Length);
        return CC[randVar];
    }

    string get_CEnd(){
        string[] CEnd = {"age","ienne","ette","re","ir","ier","es","able","oir","euille","ettes","e","eau","ent","ante","ente","eurs","ée","ete","ais","elle","le","uit","eune","aux","eux","eure","euse","eur","iste","atrice","éenne","ieux","et"};
        int randVar = random.Next(0,CEnd.Length);
        return CEnd[randVar];
    }

    string get_VEnd(){
        string[] VEnd = {"yent","le","tion","que","re","ment","tres","toire","lle","tre","son","dre","sous","ssous","trer","tant","ne","mez","ns","rde","cupe","nant","nent","vait","tait","tre","dant","vre","tent","vent","sans","sonnes","che","nue","rrêt","rier"};
        int randVar = random.Next(0,VEnd.Length);
        return VEnd[randVar];
    }

    string get_VCV(){
        string[] CC = {"qu","mm","nn","ss","dr","rd","mais","ger","man","cour","par","semb","tran","port","vers","mand","sous","tant","rier","vent","tent","vr","dr","tait"};
        int randVar = random.Next(0,CC.Length);
        return CC[randVar];
    }

    string get_CVC(){
        string[] CC = {"eu","ie","ou","ei","oi","ai","onne","eune","oire","eure","é","ete","ui","iu","ue","ieu","eau","oeur","aî","ez"};
        int randVar = random.Next(0,CC.Length);
        return CC[randVar];
    }

    string get_startV(){
        string[] CC = {"im","in","ir","il","mal","més","r","res","sur","bien","ex","ef","j"};
        int randVar = random.Next(0,CC.Length);
        return CC[randVar];
    }

    string get_startC(){
        string[] CC = {"a","ante","anti","dés","é","mau","mé","pré","pro","re","ré","contre","contra"};
        int randVar = random.Next(0,CC.Length);
        return CC[randVar];
    }

    bool start_french(ref string printString){

        bool last_was_vowel = false;

        int randVar = random.Next(0,6);

        if(randVar == 0){
            printString = get_startC();
            last_was_vowel = true;
        }
        else if(randVar == 1){
            printString = get_startV();
            last_was_vowel = false;
        }
        else if(randVar == 2 || randVar == 3){
            printString = get_PV();
            last_was_vowel = true;
        }
        else if(randVar == 4 || randVar == 5){
            printString = get_PC();
            last_was_vowel = false;
        }

        return last_was_vowel;
    }

    bool add_french(ref string printString, bool last_was_vowel){

        int MAX = 5;
        int randVar = random.Next(0,MAX);

        if(randVar <= MAX / 2){
            printString = printString + get_PV();
            last_was_vowel = true;
        }
        else if(randVar > MAX / 2 && randVar != MAX && last_was_vowel == true){
            printString = printString + get_PC();
            last_was_vowel = false;
        }
        else if(randVar == MAX && last_was_vowel == true){
            printString = printString + get_VCV();
            last_was_vowel = false;
        }
        else if(randVar == MAX && last_was_vowel == false){
            printString = printString + get_CVC();
            last_was_vowel = true;
        }
        else{
            last_was_vowel = add_french(ref printString, last_was_vowel);
        }

        return last_was_vowel;
    }

    bool is_vowel(char inChar){ 
        if(inChar == 'a' || inChar == 'i' || inChar == 'u' || inChar == 'e' || inChar == 'o'){
            return true;
        }
        return false;
    }

    void clean_french(ref string printString){

        int count = 0;

        for(int i = 2; i < printString.Length; i++){



            if(printString[i] == printString[i-2]){
                count++;
                if(count == 2){
                    printString = printString.Remove(i-2,2);
                    i = i - 2;
                }
            }
            else{
                count = 0;
            }
        }

        for(int i = 1; i < printString.Length; i++){
            if(printString[i]==printString[i-1] && is_vowel(printString[i]) == true){
                printString = printString.Remove(i-1,1);
                i = i - 1;
            }
        }

    }

    public string get_francophonie(){

        int LENGTHVAR = 3;
        int ADD_ATTEMPTS = 2;
        string printString = "";
        bool last_was_vowel = true;

        int randVar = random.Next(0,LENGTHVAR);

        last_was_vowel = start_french(ref printString);
        last_was_vowel = add_french(ref printString, last_was_vowel);

        for(int i = 0; i < ADD_ATTEMPTS; i++){
            if(randVar == 0){
                last_was_vowel = add_french(ref printString, last_was_vowel);
            }
        }

        if(last_was_vowel == true){
            printString = printString + get_VEnd();
        }
        else{
            printString = printString + get_CEnd();
        }
        
        clean_french(ref printString);

        return printString;
    }

    string get_real_french(){

        bool invalidFrench = true;
        using var reader = XmlReader.Create("realfrench.xml");
        int NUMELEMENTS = 201355;

        int randVar = random.Next(1,NUMELEMENTS);

        reader.ReadStartElement();
        
        for(int i = 0; i < randVar; i++){
            reader.ReadToFollowing("entry");
        }

        reader.ReadToFollowing("lemma");
        var data = reader.ReadElementContentAsString();
        
        while(invalidFrench == true){
            invalidFrench = false;
            for(int i = 0; i < data.Length; i++){
                if(is_number(data[i]) || data[i] == ' ' || data[i] == '\\' || data[i] == '-'){
                    reader.ReadToFollowing("entry");
                    reader.ReadToFollowing("lemma");
                    data = reader.ReadElementContentAsString();
                    invalidFrench = true;
                }
            }
        }

        return data;
    }

    bool is_number(char c){
        if(c == '0' || c == '1' || c == '2' || c == '3' || c == '4' || c == '5' || c == '6' || c == '7' || c == '8' || c == '9'){
            return true;
        }
        return false;
    }

    public string? read_french(){

        int NUMELEMENTS = 4881;
        int randVar = random.Next(0,NUMELEMENTS);
        string? french = "";
        using StreamReader file = new("frenchrepo.txt");

        for(int i = 0; i < randVar - 1; i++){
            file.ReadLine();
        }

        french = file.ReadLine();

        return french;
    }

}

/*

for(int i = 0; i < 100; i++){
    Console.Write(get_francophonie());
    Console.Write('\n');
}

for(int i = 0; i < 100; i++){
    Console.Write(read_french());
    Console.Write('\n');
}

*/